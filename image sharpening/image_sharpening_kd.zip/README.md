# Image Sharpening using Knowledge Distillation

This project demonstrates how to use a large teacher model to train a lightweight student model for image sharpening using knowledge distillation.